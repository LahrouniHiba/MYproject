use master
create database CenteMedical_Ag
use CenteMedical_Ag

-- MEDECIN
CREATE TABLE MEDECIN (
  IdMedecin INT PRIMARY KEY,
  Nom NVARCHAR(50) NOT NULL,
  Prenom NVARCHAR(50) NOT NULL,
  Specialite NVARCHAR(100) NOT NULL,
  DateRecrutement DATE NOT NULL
);

-- PATIENT
CREATE TABLE PATIENT (
  IdPatient INT PRIMARY KEY,
  Nom NVARCHAR(50) NOT NULL,
  Prenom NVARCHAR(50) NOT NULL,
  DateNaissance DATE NOT NULL,
  Telephone NVARCHAR(15) NOT NULL UNIQUE,
  CHECK (Telephone LIKE '06%' OR Telephone LIKE '07%')  -- Num�ro FR mobile
);

-- MEDICAMENT
CREATE TABLE MEDICAMENT (
  IdMedicament INT PRIMARY KEY,
  Nom NVARCHAR(100) NOT NULL UNIQUE,
  Description NVARCHAR(255),
  Prix DECIMAL(6,2) NOT NULL CHECK (Prix > 0),
  Stock INT NOT NULL DEFAULT 0 CHECK (Stock >= 0)
);

CREATE TABLE CONSULTATION (
  IdConsultation INT PRIMARY KEY,
  IdPatient INT NOT NULL,
  IdMedecin INT NULL,  -- Correction ici
  DateConsultation DATE NOT NULL,
  Diagnostic NVARCHAR(255),
  FOREIGN KEY (IdPatient) REFERENCES PATIENT(IdPatient) ON DELETE CASCADE,
  FOREIGN KEY (IdMedecin) REFERENCES MEDECIN(IdMedecin) ON DELETE SET NULL
);
-- PRESCRIPTION
CREATE TABLE PRESCRIPTION (
  IdConsultation INT NOT NULL,
  IdMedicament INT NOT NULL,
  Quantite INT NOT NULL CHECK (Quantite > 0),
  PRIMARY KEY (IdConsultation, IdMedicament),
  FOREIGN KEY (IdConsultation) REFERENCES CONSULTATION(IdConsultation) ON DELETE CASCADE,
  FOREIGN KEY (IdMedicament) REFERENCES MEDICAMENT(IdMedicament) ON DELETE CASCADE
);

-- FACTURE
CREATE TABLE FACTURE (
  IdFacture INT PRIMARY KEY,
  IdConsultation INT NOT NULL UNIQUE,
  MontantTotal DECIMAL(7,2) NOT NULL CHECK (MontantTotal >= 0),
  DateFacturation DATE NOT NULL,
  FOREIGN KEY (IdConsultation) REFERENCES CONSULTATION(IdConsultation) ON DELETE CASCADE
);

-- PAIEMENT
CREATE TABLE PAIEMENT (
  IdPaiement INT PRIMARY KEY,
  IdFacture INT NOT NULL,
  Montant DECIMAL(7,2) NOT NULL CHECK (Montant >= 0),
  DatePaiement DATE NOT NULL,
  ModePaiement NVARCHAR(20) NOT NULL CHECK (ModePaiement IN ('Carte', 'Esp�ces', 'Ch�que')),
  FOREIGN KEY (IdFacture) REFERENCES FACTURE(IdFacture) ON DELETE CASCADE
);

--partie1
1- 
SELECT SUM(MontantTotal) AS MontantTotalFacture
FROM FACTURE;
2-
SELECT AVG(Prix) AS PrixMoyenMedicaments
FROM MEDICAMENT
WHERE Stock > 0;
3-
SELECT COUNT(DISTINCT IdPatient) AS NombrePatientsAvecConsultation
FROM CONSULTATION;
4-
SELECT ModePaiement, COUNT(*) AS NombrePaiements
FROM PAIEMENT
GROUP BY ModePaiement;
5-
SELECT M.Nom, SUM(P.Quantite) AS QuantiteTotalePrescrite
FROM PRESCRIPTION P
JOIN MEDICAMENT M ON P.IdMedicament = M.IdMedicament
GROUP BY M.Nom;


--Partie II
1-
SELECT P.Nom AS NomPatient, P.Prenom AS PrenomPatient, 
       M.Nom AS NomMedecin, M.Prenom AS PrenomMedecin, C.DateConsultation
FROM CONSULTATION C
INNER JOIN PATIENT P ON C.IdPatient = P.IdPatient
INNER JOIN MEDECIN M ON C.IdMedecin = M.IdMedecin;
2-
SELECT M.*, C.IdConsultation, C.DateConsultation
FROM MEDECIN M
LEFT JOIN CONSULTATION C ON M.IdMedecin = C.IdMedecin;
3-
SELECT C.*, P.Nom AS NomPatient, P.Prenom AS PrenomPatient
FROM CONSULTATION C
RIGHT JOIN PATIENT P ON C.IdPatient = P.IdPatient;
4-
SELECT C.IdConsultation, C.DateConsultation, P.IdMedicament, P.Quantite
FROM CONSULTATION C
FULL OUTER JOIN PRESCRIPTION P ON C.IdConsultation = P.IdConsultation;
5-
SELECT P.*, PAY.Montant, PAY.DatePaiement, PAY.ModePaiement
FROM PATIENT P
LEFT JOIN CONSULTATION C ON P.IdPatient = C.IdPatient
LEFT JOIN FACTURE F ON C.IdConsultation = F.IdConsultation
LEFT JOIN PAIEMENT PAY ON F.IdFacture = PAY.IdFacture;

--Partie III
1-
SELECT M.Nom, M.Prenom, COUNT(C.IdConsultation) AS NombreConsultations
FROM MEDECIN M
LEFT JOIN CONSULTATION C ON M.IdMedecin = C.IdMedecin
GROUP BY M.IdMedecin, M.Nom, M.Prenom;
2-
SELECT ModePaiement, SUM(Montant) AS TotalPaiements
FROM PAIEMENT
GROUP BY ModePaiement;
3-
SELECT M.Nom, SUM(P.Quantite) AS QuantiteTotalePrescrite
FROM MEDICAMENT M
JOIN PRESCRIPTION P ON M.IdMedicament = P.IdMedicament
GROUP BY M.Nom
HAVING SUM(P.Quantite) > 20;
4-
SELECT YEAR(DateFacturation) AS Annee, 
       MONTH(DateFacturation) AS Mois, 
       AVG(MontantTotal) AS MontantMoyen
FROM FACTURE
GROUP BY YEAR(DateFacturation), MONTH(DateFacturation)
ORDER BY Annee, Mois;
5-
SELECT P.Nom, P.Prenom, COUNT(C.IdConsultation) AS NombreConsultations
FROM PATIENT P
JOIN CONSULTATION C ON P.IdPatient = C.IdPatient
GROUP BY P.IdPatient, P.Nom, P.Prenom
HAVING COUNT(C.IdConsultation) > 1;

--Partie IV
1-
SELECT Nom, Prix
FROM MEDICAMENT
WHERE Prix > (SELECT AVG(Prix) FROM MEDICAMENT);
2-
SELECT *
FROM PATIENT
WHERE IdPatient IN (SELECT DISTINCT IdPatient FROM CONSULTATION);
3-
SELECT *
FROM MEDECIN
WHERE IdMedecin IN (SELECT DISTINCT IdMedecin FROM CONSULTATION);
4-
SELECT P.*
FROM PATIENT P
WHERE P.IdPatient NOT IN (
    SELECT DISTINCT C.IdPatient
    FROM CONSULTATION C
    JOIN FACTURE F ON C.IdConsultation = F.IdConsultation
);
5-
SELECT M.Nom, M.Prenom, Consultations.Nombre
FROM MEDECIN M
JOIN (
    SELECT IdMedecin, COUNT(*) AS Nombre
    FROM CONSULTATION
    GROUP BY IdMedecin
) Consultations ON M.IdMedecin = Consultations.IdMedecin;

--Partie V
1-

2-
3-
4-



